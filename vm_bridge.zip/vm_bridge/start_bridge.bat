@echo off
REM ── Run this inside the Windows VM to start the MT5 Flask bridge ──
REM Fill in YOUR broker's server name below (File > Login to Trade Account in MT5).

set MT5_LOGIN=5052702771
set MT5_PASSWORD=CcZ!HhE8
set MT5_SERVER=PUT-YOUR-BROKER-SERVER-HERE

echo Starting MT5 bridge for login %MT5_LOGIN% on %MT5_SERVER% ...
python flask_mt5.py
pause
